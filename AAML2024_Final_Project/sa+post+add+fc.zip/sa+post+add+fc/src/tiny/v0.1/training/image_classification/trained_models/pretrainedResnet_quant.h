/* C array created from file src/tiny/v0.1/training/image_classification/trained_models/pretrainedResnet_quant.tflite.*/
#ifndef MLCOMMON_TINY_IMGC_MODEL_DATA
#define MLCOMMON_TINY_IMGC_MODEL_DATA
extern const unsigned char pretrainedResnet_quant[];
extern unsigned int pretrainedResnet_quant_len;
#endif